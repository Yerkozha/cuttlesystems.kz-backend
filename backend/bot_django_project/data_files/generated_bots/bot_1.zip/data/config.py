from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = 'bot_token'
